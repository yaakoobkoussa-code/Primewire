const fs = require('fs');
const path = require('path');

const DB_FILE = path.join(__dirname, 'database.json');

const DEFAULT_DATA = {
  maintenance: {
    enabled: false,
    allowed_logins: ['owner', 'admin', 'test', 'PHTM-TEST-1234-5678'],
    blocked: false,
    title: 'maintenance',
    message: "we're doing maintenance. everything is paused until we're back."
  },
  global_features: {
    marker: { enabled: true, type: 'Phantom' },
    aimLag: { enabled: false, onFire: false, onScope: false },
    fastLanding: { enabled: false, spot: 'Peak' },
    fastRevive: { enabled: false },
    gloo: { enabled: false, yawDeg: 180 },
    aimpoint: { enabled: false }
  },
  subscription_vault: {
    name: 'خزانة الاشتراك الرئيسية',
    url: '',
    button_label: 'إضافة الاشتراك'
  },
  distributors: [],
  nodes: [
    { id: 'sg1', name: 'Singapore Node 01', flag: '🇸🇬', host: 'sg1.nulldash.store', port: 443, ping: 24, status: 'online', users: 48 },
    { id: 'del1', name: 'Delhi Node 02', flag: '🇮🇳', host: 'del1.nulldash.store', port: 443, ping: 38, status: 'online', users: 29 },
    { id: 'fr1', name: 'France Node 03', flag: '🇫🇷', host: 'fr1.nulldash.store', port: 443, ping: 110, status: 'online', users: 12 }
  ],
  keys: []
};

function loadDb() {
  try {
    if (!fs.existsSync(DB_FILE)) {
      saveDb(DEFAULT_DATA);
      return DEFAULT_DATA;
    }
    const data = JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
    // Backward-compatible migration for the supplied database.json.
    if (!data.subscription_vault) data.subscription_vault = { ...DEFAULT_DATA.subscription_vault };
    if (!Array.isArray(data.distributors)) data.distributors = [];
    if (!Array.isArray(data.keys)) data.keys = [];
    return data;
  } catch (e) {
    return JSON.parse(JSON.stringify(DEFAULT_DATA));
  }
}

function saveDb(data) {
  try {
    if (!fs.existsSync(path.dirname(DB_FILE))) fs.mkdirSync(path.dirname(DB_FILE), { recursive: true });
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), 'utf8');
  } catch (e) {
    console.error('Failed to save database:', e);
  }
}

const db = {
  get() { return loadDb(); },
  update(fn) {
    const data = loadDb();
    fn(data);
    saveDb(data);
    return data;
  },
  findKey(keyStr) {
    const clean = (keyStr || '').trim().toUpperCase();
    return loadDb().keys.find(k => k.key.toUpperCase() === clean);
  },
  addKey(keyObj) { return this.update(data => data.keys.unshift(keyObj)); },
  updateKey(keyStr, updates) {
    return this.update(data => {
      const idx = data.keys.findIndex(k => k.key.toUpperCase() === keyStr.toUpperCase());
      if (idx !== -1) data.keys[idx] = { ...data.keys[idx], ...updates };
    });
  },
  deleteKey(keyStr) {
    return this.update(data => { data.keys = data.keys.filter(k => k.key.toUpperCase() !== keyStr.toUpperCase()); });
  },
  getMaintenance() { return loadDb().maintenance; },
  setMaintenance(updates) { return this.update(data => { data.maintenance = { ...data.maintenance, ...updates }; }); },
  getSubscriptionVault() { return loadDb().subscription_vault; },
  setSubscriptionVault(updates) {
    return this.update(data => { data.subscription_vault = { ...data.subscription_vault, ...updates }; });
  },
  addDistributor(distributor) { return this.update(data => data.distributors.unshift(distributor)); },
  updateDistributor(id, updates) {
    return this.update(data => {
      const idx = data.distributors.findIndex(item => item.id === id);
      if (idx !== -1) data.distributors[idx] = { ...data.distributors[idx], ...updates };
    });
  },
  deleteDistributor(id) {
    return this.update(data => {
      data.distributors = data.distributors.filter(item => item.id !== id);
      data.keys = data.keys.map(key => key.distributor_id === id ? { ...key, distributor_id: null } : key);
    });
  }
};

module.exports = db;
